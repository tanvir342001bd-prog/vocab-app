// প্রথমবার অ্যাপ খুললে এই ডেমো ডাটা লোড হয়।
// এরপর অ্যাডমিন প্যানেল থেকে যা যোগ/এডিট করবেন, সেটাই থাকবে।
// পরে এই ফাইলের বদলে Firebase থেকে ডাটা আসবে — গঠন একই রাখলে কোড বদলাতে হবে না।
window.SEED = {
  users: [
    // ডেমো অ্যাডমিন — ইমেইল: admin@vocabmaster.app  পাসওয়ার্ড: admin123
    { id: "u_admin", name: "Admin", email: "admin@vocabmaster.app", passHash: "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9", role: "admin", joined: "2026-11-01" }
  ],

  vocab: [
    // ---------- Reading ----------
    { id: "v1", part: "reading", word: "Prevail", pos: "verb", bn: "জয়ী হওয়া; প্রাধান্য পাওয়া",
      synonyms: ["triumph", "win", "dominate"], antonyms: ["lose", "fail", "yield"],
      examples: ["Justice will prevail in the end.", "A sense of calm prevailed after the storm."] },
    { id: "v2", part: "reading", word: "Abundant", pos: "adjective", bn: "প্রচুর; অঢেল",
      synonyms: ["plentiful", "ample", "copious"], antonyms: ["scarce", "sparse", "insufficient"],
      examples: ["The region has abundant natural resources.", "Fresh fruit is abundant in summer."] },
    { id: "v3", part: "reading", word: "Deteriorate", pos: "verb", bn: "অবনতি হওয়া",
      synonyms: ["decline", "worsen", "degrade"], antonyms: ["improve", "recover", "enhance"],
      examples: ["Air quality tends to deteriorate in winter.", "His health deteriorated rapidly after the accident."] },
    { id: "v4", part: "reading", word: "Inevitable", pos: "adjective", bn: "অনিবার্য",
      synonyms: ["unavoidable", "certain", "inescapable"], antonyms: ["avoidable", "uncertain", "preventable"],
      examples: ["Change is inevitable in every society.", "Delays were inevitable because of the heavy rain."] },
    { id: "v5", part: "reading", word: "Substantial", pos: "adjective", bn: "উল্লেখযোগ্য; যথেষ্ট",
      synonyms: ["considerable", "significant", "large"], antonyms: ["minor", "small", "negligible"],
      examples: ["The project received substantial funding.", "There has been a substantial rise in prices."] },
    { id: "v6", part: "reading", word: "Mitigate", pos: "verb", bn: "প্রশমিত করা; কমানো",
      synonyms: ["reduce", "alleviate", "ease"], antonyms: ["aggravate", "worsen", "intensify"],
      examples: ["Planting trees can mitigate the effects of pollution.", "The new law aims to mitigate poverty."] },
    { id: "v7", part: "reading", word: "Diminish", pos: "verb", bn: "কমে যাওয়া; হ্রাস পাওয়া",
      synonyms: ["decrease", "lessen", "decline"], antonyms: ["increase", "grow", "expand"],
      examples: ["The pain diminished after a few days.", "Forests are diminishing at an alarming rate."] },
    { id: "v8", part: "reading", word: "Vital", pos: "adjective", bn: "অত্যাবশ্যক; অপরিহার্য",
      synonyms: ["essential", "crucial", "critical"], antonyms: ["unimportant", "trivial", "minor"],
      examples: ["Water is vital for all living things.", "Regular exercise plays a vital role in good health."] },

    // ---------- Listening ----------
    { id: "v9", part: "listening", word: "Available", pos: "adjective", bn: "পাওয়া যায় এমন; সহজলভ্য",
      synonyms: ["accessible", "obtainable", "free"], antonyms: ["unavailable", "occupied", "inaccessible"],
      examples: ["Is the double room still available?", "Tickets are available at the front desk."] },
    { id: "v10", part: "listening", word: "Reserve", pos: "verb", bn: "সংরক্ষণ করা; বুক করা",
      synonyms: ["book", "hold", "secure"], antonyms: ["release", "cancel", "relinquish"],
      examples: ["I'd like to reserve a table for four.", "You should reserve your seat a week in advance."] },
    { id: "v11", part: "listening", word: "Approximately", pos: "adverb", bn: "প্রায়; আনুমানিক",
      synonyms: ["roughly", "about", "nearly"], antonyms: ["exactly", "precisely", "accurately"],
      examples: ["The tour lasts approximately two hours.", "Approximately fifty people attended the meeting."] },
    { id: "v12", part: "listening", word: "Compulsory", pos: "adjective", bn: "বাধ্যতামূলক",
      synonyms: ["mandatory", "required", "obligatory"], antonyms: ["optional", "voluntary", "elective"],
      examples: ["Attendance at the first lecture is compulsory.", "Wearing a helmet is compulsory on the site."] },
    { id: "v13", part: "listening", word: "Affordable", pos: "adjective", bn: "সাশ্রয়ী; সামর্থ্যের মধ্যে",
      synonyms: ["cheap", "inexpensive", "reasonable"], antonyms: ["expensive", "costly", "overpriced"],
      examples: ["Students need affordable accommodation.", "The gym offers an affordable monthly plan."] },
    { id: "v14", part: "listening", word: "Convenient", pos: "adjective", bn: "সুবিধাজনক",
      synonyms: ["handy", "suitable", "accessible"], antonyms: ["inconvenient", "awkward", "unsuitable"],
      examples: ["Is Monday morning convenient for you?", "The hotel is in a convenient location."] },
    { id: "v15", part: "listening", word: "Temporary", pos: "adjective", bn: "অস্থায়ী",
      synonyms: ["short-term", "brief", "provisional"], antonyms: ["permanent", "lasting", "enduring"],
      examples: ["She found a temporary job for the summer.", "The library is in a temporary building."] },
    { id: "v16", part: "listening", word: "Confirm", pos: "verb", bn: "নিশ্চিত করা",
      synonyms: ["verify", "validate", "affirm"], antonyms: ["deny", "cancel", "refute"],
      examples: ["Please confirm your booking by email.", "Can you confirm your date of birth?"] }
  ],

  passages: [
    { id: "p1", title: "The Value of Urban Trees", level: "Academic",
      text: "Cities around the world are discovering that trees are vital to urban life. A substantial body of research shows that green spaces mitigate the heat that builds up in concrete streets during summer.\n\nWhere trees are abundant, air quality is noticeably better, and residents report lower levels of stress. However, as cities grow, green areas often diminish, and the quality of the environment can deteriorate quickly.\n\nPlanners now argue that some loss of open land may be inevitable, but careful design can ensure that nature continues to prevail in the modern city." },
    { id: "p2", title: "Learning a Second Language", level: "General Training",
      text: "Learning a new language is vital for many people who plan to study or work abroad. Although mistakes are inevitable at the beginning, regular practice can make a substantial difference.\n\nExperts recommend reading short texts every day. Over time, the fear of speaking will diminish and confidence will grow." }
  ],

  audios: [
    { id: "a1", title: "Hotel Booking Conversation", book: "Book 10", test: "Test 1", section: "Part 1", url: "", transcript: "" },
    { id: "a2", title: "Campus Library Tour", book: "Book 10", test: "Test 1", section: "Part 2", url: "", transcript: "" }
  ],

  writing: [
    { id: "w1", task: "Task 2",
      topic: "Some people believe that university education should be free for everyone. To what extent do you agree or disagree?",
      vocab: [{ word: "accessible", bn: "সহজলভ্য" }, { word: "financial burden", bn: "আর্থিক বোঝা" }, { word: "equitable", bn: "ন্যায্য" }, { word: "funding", bn: "অর্থায়ন" }] },
    { id: "w2", task: "Task 2",
      topic: "Many cities suffer from traffic congestion. What are the causes of this problem and what solutions can you suggest?",
      vocab: [{ word: "congestion", bn: "যানজট" }, { word: "commute", bn: "নিয়মিত যাতায়াত" }, { word: "infrastructure", bn: "অবকাঠামো" }, { word: "alleviate", bn: "লাঘব করা" }] },
    { id: "w3", task: "Task 1",
      topic: "The line graph shows the number of international tourists who visited three countries between 2000 and 2020. Summarise the information by selecting and reporting the main features.",
      vocab: [{ word: "fluctuate", bn: "ওঠানামা করা" }, { word: "surge", bn: "হঠাৎ বৃদ্ধি" }, { word: "plateau", bn: "স্থির অবস্থায় থাকা" }, { word: "decline", bn: "হ্রাস পাওয়া" }] }
  ],

  cueCards: [
    { id: "c1", topic: "Describe a book you recently read.",
      points: ["What the book was", "When you read it", "What it was about", "And explain why you liked it"],
      vocab: [{ word: "gripping", bn: "টানটান; আকর্ষণীয়" }, { word: "insightful", bn: "অন্তর্দৃষ্টিপূর্ণ" }, { word: "page-turner", bn: "একটানা পড়ার মতো বই" }, { word: "protagonist", bn: "প্রধান চরিত্র" }] },
    { id: "c2", topic: "Describe a place you would like to visit.",
      points: ["Where it is", "How you know about it", "What you would do there", "And explain why you want to go there"],
      vocab: [{ word: "breathtaking", bn: "মনোমুগ্ধকর" }, { word: "bustling", bn: "কোলাহলপূর্ণ; প্রাণবন্ত" }, { word: "serene", bn: "শান্ত; নির্মল" }, { word: "itinerary", bn: "ভ্রমণসূচি" }] },
    { id: "c3", topic: "Describe a person who has influenced you.",
      points: ["Who this person is", "How you know them", "What they have done", "And explain how they influenced you"],
      vocab: [{ word: "mentor", bn: "পথপ্রদর্শক" }, { word: "inspiring", bn: "অনুপ্রেরণাদায়ক" }, { word: "perseverance", bn: "অধ্যবসায়" }, { word: "role model", bn: "আদর্শ ব্যক্তি" }] }
  ],

  notifications: [
    { id: "n1", title: "Welcome to IELTS VocabMaster", body: "Start with Reading vocabulary and set your daily goal in Plan.", date: "2026-11-01" },
    { id: "n2", title: "New cue cards added", body: "Three new Speaking cue cards with Bangla meanings are ready.", date: "2026-11-01" }
  ]
};
