// VocabBox demo app — hash routing, কোনো সার্ভার লাগে না।
(function () {
  "use strict";

  var WORDS = window.WORDS || [];
  var app = document.getElementById("app");
  var LEVELS = ["সব", "IELTS", "বেসিক", "ফ্রেজ", "GRE"];
  var DAILY_GOAL = 10;

  // ---------- storage (localStorage, ব্যর্থ হলেও অ্যাপ চলবে) ----------
  function load(key, fallback) {
    try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
    catch (e) { return fallback; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* ignore */ }
  }
  var state = {
    saved: load("vb_saved", []),
    learned: load("vb_learned", []),
    level: "সব",
    query: "",
    cardIndex: 0,
    cardFlipped: false
  };

  // ---------- helpers ----------
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function bnNum(n) {
    return String(n).replace(/\d/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; });
  }
  function byId(id) { return WORDS.find(function (w) { return w.id === Number(id); }); }
  function isSaved(id) { return state.saved.indexOf(id) !== -1; }
  function toggleSaved(id) {
    var i = state.saved.indexOf(id);
    if (i === -1) state.saved.push(id); else state.saved.splice(i, 1);
    save("vb_saved", state.saved);
  }
  function markLearned(id) {
    if (state.learned.indexOf(id) === -1) { state.learned.push(id); save("vb_learned", state.learned); }
  }
  function wordOfDay() {
    var day = Math.floor(Date.now() / 86400000);
    return WORDS[day % WORDS.length];
  }
  function greeting() {
    var h = new Date().getHours();
    if (h < 12) return "শুভ সকাল";
    if (h < 15) return "শুভ দুপুর";
    if (h < 18) return "শুভ বিকাল";
    if (h < 20) return "শুভ সন্ধ্যা";
    return "শুভ রাত্রি";
  }
  function speak(text) {
    // ডেমোতে ফোনের নিজস্ব ভয়েস; পরে Cloudflare-এর অডিও ফাইল চলবে।
    if (!("speechSynthesis" in window)) return;
    var u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US"; u.rate = 0.9;
    speechSynthesis.cancel(); speechSynthesis.speak(u);
  }
  function shuffle(a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  var ICON = {
    speaker: '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
    back: '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>',
    search: '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" style="color:#4E6A62"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    arrow: '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" style="width:16px;height:16px"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>',
    bookmark: '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>',
    bookmarkFill: '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" style="fill:currentColor"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>'
  };

  function itemHTML(w) {
    return '<a class="item" href="#/word/' + w.id + '">' +
      '<span class="letter display">' + esc(w.word.charAt(0)) + '</span>' +
      '<span class="txt"><b>' + esc(w.word) + '</b><span class="bn">' + esc(w.bn) + '</span></span>' +
      '<button class="icon-btn solid" data-speak="' + esc(w.word) + '" aria-label="' + esc(w.word) + ' উচ্চারণ শুনুন">' + ICON.speaker + '</button>' +
      '</a>';
  }

  // ---------- screens ----------
  function filteredWords() {
    var q = state.query.trim().toLowerCase();
    return WORDS.filter(function (w) {
      var okLevel = state.level === "সব" || w.level === state.level;
      var okQuery = !q || w.word.toLowerCase().indexOf(q) !== -1 || w.bn.indexOf(q) !== -1;
      return okLevel && okQuery;
    });
  }

  function renderHomeList() {
    var list = filteredWords();
    var box = document.getElementById("word-list");
    if (!box) return;
    box.innerHTML = list.length
      ? list.map(itemHTML).join("")
      : '<p class="empty">কোনো শব্দ পাওয়া যায়নি।</p>';
  }

  function home() {
    var w = wordOfDay();
    var learnedToday = Math.min(state.learned.length, DAILY_GOAL);
    var pct = Math.round((learnedToday / DAILY_GOAL) * 100);
    app.innerHTML =
      '<header class="top"><div><small>' + greeting() + '</small><h1>আজ কী শিখবেন?</h1></div></header>' +
      '<label class="search"><span class="sr-only">শব্দ খুঁজুন</span>' + ICON.search +
      '<input id="q" type="search" placeholder="ইংরেজি বা বাংলায় খুঁজুন…" value="' + esc(state.query) + '" autocomplete="off"></label>' +
      '<a class="hero" href="#/word/' + w.id + '">' +
        '<div class="row-between"><span class="eyebrow">Word of the day</span><span class="badge">' + esc(w.level) + '</span></div>' +
        '<span class="word display">' + esc(w.word) + '</span>' +
        '<span class="meaning bn">' + esc(w.bn) + '</span>' +
        '<span class="more">বিস্তারিত দেখুন ' + ICON.arrow + '</span>' +
      '</a>' +
      '<div class="chips" role="group" aria-label="লেভেল">' +
        LEVELS.map(function (l) {
          return '<button class="chip" data-level="' + esc(l) + '" aria-pressed="' + (l === state.level) + '">' + esc(l) + '</button>';
        }).join("") +
      '</div>' +
      '<div class="stats">' +
        '<div class="stat"><span>শেখা শব্দ</span><b class="display">' + bnNum(state.learned.length) + ' / ' + bnNum(WORDS.length) + '</b></div>' +
        '<div class="stat"><span>আজকের লক্ষ্য</span><div class="bar"><i style="width:' + pct + '%"></i></div><b style="font-size:14px">' + bnNum(learnedToday) + ' / ' + bnNum(DAILY_GOAL) + '</b></div>' +
      '</div>' +
      '<div class="section-title"><h2>সব শব্দ</h2></div>' +
      '<div class="list" id="word-list"></div>';
    renderHomeList();

    var input = document.getElementById("q");
    input.addEventListener("input", function () { state.query = input.value; renderHomeList(); });
  }

  function detail(id) {
    var w = byId(id);
    if (!w) { location.hash = "#/"; return; }
    var saved = isSaved(w.id);
    app.innerHTML =
      '<section class="detail-top">' +
        '<div class="row-between">' +
          '<button class="icon-btn" data-action="back" aria-label="পিছনে যান">' + ICON.back + '</button>' +
          '<button class="icon-btn" data-action="save" data-id="' + w.id + '" aria-pressed="' + saved + '" aria-label="' + (saved ? 'সেভ থেকে সরান' : 'সেভ করুন') + '">' + (saved ? ICON.bookmarkFill : ICON.bookmark) + '</button>' +
        '</div>' +
        '<div><span class="pos">' + esc(w.pos) + '</span></div>' +
        '<span class="word display">' + esc(w.word) + '</span>' +
        '<div class="row-between"><span class="ipa">' + esc(w.ipa) + '</span>' +
        '<button class="icon-btn" data-speak="' + esc(w.word) + '" aria-label="উচ্চারণ শুনুন">' + ICON.speaker + '</button></div>' +
      '</section>' +
      '<div class="card"><h3>বাংলা অর্থ</h3><div class="meaning-big bn">' + esc(w.bn) + '</div></div>' +
      '<div class="card"><h3>উদাহরণ</h3><blockquote>' + esc(w.example) + '</blockquote></div>' +
      '<div class="card"><h3>সমার্থক ও বিপরীত</h3><div class="tags">' +
        w.synonyms.map(function (s) { return '<span class="tag">' + esc(s) + '</span>'; }).join("") +
        w.antonyms.map(function (s) { return '<span class="tag anti">≠ ' + esc(s) + '</span>'; }).join("") +
      '</div></div>' +
      '<button class="btn" data-action="learned" data-id="' + w.id + '">' +
        (state.learned.indexOf(w.id) !== -1 ? 'শেখা হয়েছে ✓' : 'শিখে ফেলেছি') + '</button>';
  }

  function cards() {
    var list = WORDS;
    var w = list[state.cardIndex % list.length];
    var flipped = state.cardFlipped;
    app.innerHTML =
      '<header class="top"><div><small>ট্যাপ করে উল্টান</small><h1>ফ্ল্যাশকার্ড</h1></div></header>' +
      '<button class="flash' + (flipped ? ' back' : '') + '" data-action="flip" aria-label="কার্ড উল্টান">' +
        (flipped
          ? '<span class="bn" style="font-size:30px;font-weight:600;color:#0F5C4A">' + esc(w.bn) + '</span><span class="hint">' + esc(w.example) + '</span>'
          : '<span class="word display">' + esc(w.word) + '</span><span class="hint">' + esc(w.ipa) + '</span>') +
      '</button>' +
      '<p class="counter">' + bnNum(state.cardIndex % list.length + 1) + ' / ' + bnNum(list.length) + '</p>' +
      '<div class="btn-row">' +
        '<button class="btn ghost" data-action="prev">আগের</button>' +
        '<button class="btn" data-action="next">পরের</button>' +
      '</div>' +
      '<button class="btn ghost" data-speak="' + esc(w.word) + '">' + ICON.speaker + ' উচ্চারণ শুনুন</button>';
  }

  var quiz = null;
  function newQuestion() {
    var answer = WORDS[Math.floor(Math.random() * WORDS.length)];
    var others = shuffle(WORDS.filter(function (w) { return w.id !== answer.id; })).slice(0, 3);
    quiz = { answer: answer, options: shuffle([answer].concat(others)), picked: null, score: quiz ? quiz.score : 0, total: quiz ? quiz.total : 0 };
  }
  function quizScreen() {
    if (!quiz) newQuestion();
    var done = quiz.picked !== null;
    app.innerHTML =
      '<header class="top"><div><small>স্কোর: ' + bnNum(quiz.score) + ' / ' + bnNum(quiz.total) + '</small><h1>কুইজ</h1></div></header>' +
      '<div class="card"><p class="question" style="margin:0"><b>' + esc(quiz.answer.word) + '</b>এই শব্দের সঠিক বাংলা অর্থ কোনটি?</p></div>' +
      '<div class="options">' +
        quiz.options.map(function (o) {
          var cls = "option bn";
          if (done && o.id === quiz.answer.id) cls += " correct";
          else if (done && o.id === quiz.picked) cls += " wrong";
          return '<button class="' + cls + '" data-pick="' + o.id + '"' + (done ? ' disabled' : '') + '>' + esc(o.bn) + '</button>';
        }).join("") +
      '</div>' +
      '<p class="feedback ' + (done ? (quiz.picked === quiz.answer.id ? 'ok' : 'no') : '') + '">' +
        (done ? (quiz.picked === quiz.answer.id ? '✓ সঠিক উত্তর!' : 'ভুল হয়েছে — সঠিক উত্তর সবুজ রঙে দেখানো হলো') : '') + '</p>' +
      (done ? '<button class="btn" data-action="next-q">পরের প্রশ্ন</button>' : '');
  }

  function saved() {
    var list = WORDS.filter(function (w) { return isSaved(w.id); });
    app.innerHTML =
      '<header class="top"><div><small>' + bnNum(list.length) + 'টি শব্দ</small><h1>সেভ করা শব্দ</h1></div></header>' +
      (list.length
        ? '<div class="list">' + list.map(itemHTML).join("") + '</div>'
        : '<p class="empty">এখনো কোনো শব্দ সেভ করেননি।<br>শব্দের পেজে বুকমার্ক বাটন চেপে সেভ করুন।</p>');
  }

  // ---------- router ----------
  function route() {
    var h = location.hash.replace(/^#/, "") || "/";
    var tab = "home";
    if (h.indexOf("/word/") === 0) { detail(h.split("/")[2]); tab = ""; }
    else if (h === "/cards") { cards(); tab = "cards"; }
    else if (h === "/quiz") { quizScreen(); tab = "quiz"; }
    else if (h === "/saved") { saved(); tab = "saved"; }
    else { home(); }
    document.querySelectorAll(".tabbar a").forEach(function (a) {
      var on = a.getAttribute("data-tab") === tab;
      a.classList.toggle("active", on);
      if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
    window.scrollTo(0, 0);
  }

  // ---------- events (একটি listener দিয়ে সব বাটন) ----------
  app.addEventListener("click", function (e) {
    var el = e.target.closest("button");
    if (!el) return;

    if (el.hasAttribute("data-speak")) {
      e.preventDefault(); e.stopPropagation();
      speak(el.getAttribute("data-speak"));
      return;
    }
    if (el.hasAttribute("data-level")) {
      state.level = el.getAttribute("data-level");
      document.querySelectorAll(".chip").forEach(function (c) {
        c.setAttribute("aria-pressed", String(c === el));
      });
      renderHomeList();
      return;
    }
    if (el.hasAttribute("data-pick")) {
      quiz.picked = Number(el.getAttribute("data-pick"));
      quiz.total += 1;
      if (quiz.picked === quiz.answer.id) { quiz.score += 1; markLearned(quiz.answer.id); }
      quizScreen();
      return;
    }

    var action = el.getAttribute("data-action");
    var id = Number(el.getAttribute("data-id"));
    if (action === "back") { history.length > 1 ? history.back() : (location.hash = "#/"); }
    else if (action === "save") { toggleSaved(id); detail(id); }
    else if (action === "learned") { markLearned(id); detail(id); }
    else if (action === "flip") { state.cardFlipped = !state.cardFlipped; cards(); }
    else if (action === "next") { state.cardIndex = (state.cardIndex + 1) % WORDS.length; state.cardFlipped = false; cards(); }
    else if (action === "prev") { state.cardIndex = (state.cardIndex - 1 + WORDS.length) % WORDS.length; state.cardFlipped = false; cards(); }
    else if (action === "next-q") { newQuestion(); quizScreen(); }
  });

  window.addEventListener("hashchange", route);
  route();

  // ---------- PWA: অফলাইনে চালানোর জন্য ----------
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("sw.js").catch(function () { /* ignore */ });
    });
  }
})();
