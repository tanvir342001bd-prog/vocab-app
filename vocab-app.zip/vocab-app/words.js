// ডেমো ডাটা — পরে এই ফাইলের বদলে Firebase থেকে শব্দ আসবে।
// প্রতিটি শব্দের গঠন Firebase-এও একই রাখলে কোড বদলাতে হবে না।
window.WORDS = [
  { id: 1, word: "Resilient", pos: "adjective", ipa: "/rɪˈzɪl.i.ənt/", bn: "স্থিতিস্থাপক; সহজে হার না মানা", example: "She is resilient enough to bounce back from failure.", synonyms: ["tough", "strong"], antonyms: ["fragile"], level: "IELTS" },
  { id: 2, word: "Abundant", pos: "adjective", ipa: "/əˈbʌn.dənt/", bn: "প্রচুর; অঢেল", example: "Water is abundant in this region.", synonyms: ["plentiful", "ample"], antonyms: ["scarce"], level: "বেসিক" },
  { id: 3, word: "Ubiquitous", pos: "adjective", ipa: "/juːˈbɪk.wɪ.təs/", bn: "সর্বব্যাপী", example: "Smartphones have become ubiquitous.", synonyms: ["everywhere", "pervasive"], antonyms: ["rare"], level: "GRE" },
  { id: 4, word: "Diligent", pos: "adjective", ipa: "/ˈdɪl.ɪ.dʒənt/", bn: "পরিশ্রমী; মনোযোগী", example: "He is a diligent student.", synonyms: ["hardworking"], antonyms: ["lazy"], level: "বেসিক" },
  { id: 5, word: "Mitigate", pos: "verb", ipa: "/ˈmɪt.ɪ.ɡeɪt/", bn: "প্রশমিত করা; কমানো", example: "Trees help mitigate the effects of pollution.", synonyms: ["reduce", "ease"], antonyms: ["worsen"], level: "IELTS" },
  { id: 6, word: "Ephemeral", pos: "adjective", ipa: "/ɪˈfem.ər.əl/", bn: "ক্ষণস্থায়ী", example: "Fame on social media is often ephemeral.", synonyms: ["short-lived", "brief"], antonyms: ["permanent"], level: "GRE" },
  { id: 7, word: "Comprehensive", pos: "adjective", ipa: "/ˌkɒm.prɪˈhen.sɪv/", bn: "ব্যাপক; সম্পূর্ণ", example: "The book gives a comprehensive overview.", synonyms: ["complete", "thorough"], antonyms: ["partial"], level: "IELTS" },
  { id: 8, word: "Candid", pos: "adjective", ipa: "/ˈkæn.dɪd/", bn: "স্পষ্টবাদী; অকপট", example: "Thank you for your candid opinion.", synonyms: ["frank", "honest"], antonyms: ["secretive"], level: "বেসিক" },
  { id: 9, word: "Deteriorate", pos: "verb", ipa: "/dɪˈtɪə.ri.ə.reɪt/", bn: "অবনতি হওয়া", example: "His health began to deteriorate.", synonyms: ["decline", "worsen"], antonyms: ["improve"], level: "IELTS" },
  { id: 10, word: "Meticulous", pos: "adjective", ipa: "/məˈtɪk.jə.ləs/", bn: "অতি যত্নশীল; খুঁতখুঁতে", example: "She keeps meticulous records.", synonyms: ["careful", "precise"], antonyms: ["careless"], level: "GRE" },
  { id: 11, word: "Break down", pos: "phrase", ipa: "/breɪk daʊn/", bn: "নষ্ট হয়ে যাওয়া; ভেঙে পড়া", example: "My car broke down on the highway.", synonyms: ["fail", "collapse"], antonyms: ["work"], level: "ফ্রেজ" },
  { id: 12, word: "Look forward to", pos: "phrase", ipa: "/lʊk ˈfɔː.wəd tuː/", bn: "অপেক্ষায় থাকা", example: "I look forward to meeting you.", synonyms: ["anticipate"], antonyms: ["dread"], level: "ফ্রেজ" },
  { id: 13, word: "Inevitable", pos: "adjective", ipa: "/ɪˈnev.ɪ.tə.bəl/", bn: "অনিবার্য", example: "Change is inevitable.", synonyms: ["unavoidable", "certain"], antonyms: ["avoidable"], level: "IELTS" },
  { id: 14, word: "Gratitude", pos: "noun", ipa: "/ˈɡræt.ɪ.tʃuːd/", bn: "কৃতজ্ঞতা", example: "She expressed her gratitude to the teachers.", synonyms: ["thankfulness"], antonyms: ["ingratitude"], level: "বেসিক" },
  { id: 15, word: "Pragmatic", pos: "adjective", ipa: "/præɡˈmæt.ɪk/", bn: "বাস্তববাদী", example: "We need a pragmatic solution.", synonyms: ["practical", "realistic"], antonyms: ["idealistic"], level: "GRE" }
];
