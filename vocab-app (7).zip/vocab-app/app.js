/* IELTS VocabMaster — demo app
 * ডেমো ভার্সন: সব ডাটা ও অ্যাকাউন্ট এই ফোনের ব্রাউজারে (localStorage) থাকে।
 * পরে Firebase যুক্ত হলে Store অংশটা বদলালেই হবে, বাকি স্ক্রিন একই থাকবে।
 */
(function () {
  "use strict";

  var app = document.getElementById("app");
  var sidebar = document.getElementById("sidebar");
  var scrim = document.getElementById("scrim");
  var tabbar = document.getElementById("tabbar");
  var menuBtn = document.getElementById("menuBtn");

  var PARTS = {
    reading:   { name: "Reading",   cls: "reading" },
    listening: { name: "Listening", cls: "listening" },
    writing:   { name: "Writing",   cls: "writing" },
    speaking:  { name: "Speaking",  cls: "speaking" }
  };

  /* ================= Store ================= */
  var DB_KEY = "vm_db_v1";
  var SESSION_KEY = "vm_session";
  var memory = {}; // localStorage বন্ধ থাকলে এখানে থাকবে

  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return memory[k] || null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { memory[k] = v; } }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) { delete memory[k]; } }

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  var db = (function () {
    try { var raw = lsGet(DB_KEY); if (raw) return JSON.parse(raw); } catch (e) { /* fall through */ }
    return clone(window.SEED);
  })();
  ["users", "vocab", "passages", "audios", "writing", "cueCards", "notifications"].forEach(function (k) {
    if (!Array.isArray(db[k])) db[k] = clone(window.SEED[k] || []);
  });
  function saveDb() { lsSet(DB_KEY, JSON.stringify(db)); }
  saveDb();

  function uid(prefix) { return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function find(coll, id) { return db[coll].find(function (x) { return x.id === id; }); }

  // ---- session ----
  function getSession() { try { return JSON.parse(lsGet(SESSION_KEY) || "null"); } catch (e) { return null; } }
  function setSession(s) { if (s) lsSet(SESSION_KEY, JSON.stringify(s)); else lsDel(SESSION_KEY); }
  function currentUser() {
    var s = getSession();
    if (!s) return null;
    if (s.guest) return { id: "guest", name: "Guest", role: "guest" };
    return find("users", s.uid) || null;
  }
  function isAdmin() { var u = currentUser(); return !!u && u.role === "admin"; }

  // ---- progress (প্রতিটি অ্যাকাউন্টের আলাদা) ----
  function today() {
    var d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }
  function progKey() { var u = currentUser(); return "vm_prog_" + (u ? u.id : "none"); }
  function getProg() {
    var p;
    try { p = JSON.parse(lsGet(progKey()) || "null"); } catch (e) { p = null; }
    p = p || {};
    p.learned = p.learned || [];
    p.goal = p.goal || 10;
    if (!p.day || p.day.date !== today()) p.day = { date: today(), count: 0, tasks: {} };
    return p;
  }
  function saveProg(p) { lsSet(progKey(), JSON.stringify(p)); }
  function isLearned(id) { return getProg().learned.indexOf(id) !== -1; }
  function toggleLearned(id) {
    var p = getProg(); var i = p.learned.indexOf(id);
    if (i === -1) { p.learned.push(id); p.day.count += 1; }
    else { p.learned.splice(i, 1); p.day.count = Math.max(0, p.day.count - 1); }
    saveProg(p);
  }

  // ---- password hash ----
  function sha256(text) {
    if (window.crypto && crypto.subtle && window.TextEncoder) {
      return crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)).then(function (buf) {
        return Array.prototype.map.call(new Uint8Array(buf), function (b) { return b.toString(16).padStart(2, "0"); }).join("");
      });
    }
    return Promise.resolve("plain:" + text);
  }

  /* ================= Helpers ================= */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function initial(name) { return esc((name || "?").trim().charAt(0).toUpperCase() || "?"); }
  function highlight(text, words) {
    var out = esc(text);
    words.filter(Boolean).forEach(function (w) {
      var safe = esc(w).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      out = out.replace(new RegExp("\\b(" + safe + "\\w*)", "gi"), "<mark>$1</mark>");
    });
    return out;
  }
  var IN_APK = !!window.AndroidTTS;
  function speak(text) {
    if (IN_APK) { try { window.AndroidTTS.speak(text); } catch (e) { /* ignore */ } return; }
    if (!("speechSynthesis" in window)) return;
    var u = new SpeechSynthesisUtterance(text); u.lang = "en-GB"; u.rate = 0.9;
    speechSynthesis.cancel(); speechSynthesis.speak(u);
  }
  function go(hash) { if (location.hash === hash) route(); else location.hash = hash; }

  var I = {
    arrow: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>',
    back: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>',
    layers: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/></svg>',
    speaker: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>',
    search: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    check: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
    home: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg>',
    plan: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/><path d="m9 16 2 2 4-4"/></svg>',
    plus: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
    book: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 5c4-1.5 7-1 10 1.5V20c-3-2.5-6-3-10-1.5z"/><path d="M22 5c-4-1.5-7-1-10 1.5V20c3-2.5 6-3 10-1.5z"/></svg>',
    chart: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/></svg>',
    bell: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>',
    user: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>',
    doc: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h6"/></svg>',
    headphones: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1v-6h3zM3 19a2 2 0 0 0 2 2h1v-6H3z"/></svg>',
    pen: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
    mic: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v4"/></svg>',
    shield: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    logout: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/></svg>',
    login: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/></svg>',
    trans: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M6 15l2-6 2 6M6.7 13h2.6M14 9h4M16 9v6M14 15h4"/></svg>'
  };
  var LOGO = '<svg viewBox="0 0 200 200" aria-hidden="true"><rect width="200" height="200" rx="46" fill="#0F5848"/><circle cx="100" cy="52" r="16" fill="#FFFFFF"/><path d="M36 82c24-10 46-6 64 10v74c-18-16-40-20-64-10z" fill="#FFFFFF"/><path d="M164 82c-24-10-46-6-64 10v74c18-16 40-20 64-10z" fill="#FFFFFF"/><path d="M78 112l22 26 22-26" fill="none" stroke="#0F5848" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function backBtn(href) { return '<a class="back" href="' + href + '" aria-label="Back">' + I.back + "</a>"; }

  /* ================= Install (PWA) ================= */
  var installEvt = null;
  window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); installEvt = e; rerenderSoft(); });
  window.addEventListener("appinstalled", function () { installEvt = null; rerenderSoft(); });
  function rerenderSoft() { if (document.readyState !== "loading" && app.innerHTML) { var y = window.scrollY; route(); window.scrollTo(0, y); } }
  function installCard() {
    if (!installEvt) return "";
    return '<div class="install-card"><div>' + '<b>Install VocabMaster</b><span>Add the app to your home screen</span></div>' +
      '<button class="btn small" data-act="install">Install app</button></div>';
  }

  /* ================= Screens ================= */
  var ui = { authTab: "signin", authMsg: "", query: "", writingFilter: "All", adminTab: "vocab", editId: null, adminMsg: "" };

  // ---------- Auth ----------
  function authScreen() {
    var signin = ui.authTab === "signin";
    return '<div class="auth-wrap">' +
      '<div class="auth-logo">' + LOGO + '<span class="brand-text">Vocab<b>Master</b></span><p>Master IELTS words — with Bangla meanings</p></div>' +
      '<div class="seg" role="group" aria-label="Account">' +
        '<button data-act="auth-tab" data-v="signin" aria-pressed="' + signin + '">Sign in</button>' +
        '<button data-act="auth-tab" data-v="signup" aria-pressed="' + !signin + '">Sign up</button>' +
      "</div>" +
      (ui.authMsg ? '<div class="msg ' + ui.authMsg.type + '">' + esc(ui.authMsg.text) + "</div>" : "") +
      '<form class="form card" data-form="' + (signin ? "signin" : "signup") + '">' +
        (signin ? "" : '<div class="field"><label for="f-name">Full name</label><input id="f-name" name="name" autocomplete="name" required></div>') +
        '<div class="field"><label for="f-email">Email</label><input id="f-email" name="email" type="email" autocomplete="email" required></div>' +
        '<div class="field"><label for="f-pass">Password</label><input id="f-pass" name="pass" type="password" minlength="6" autocomplete="' + (signin ? "current-password" : "new-password") + '" required></div>' +
        '<button class="btn block" type="submit">' + (signin ? "Sign in" : "Create student account") + "</button>" +
      "</form>" +
      '<div class="divider">or</div>' +
      '<button class="btn ghost block" data-act="guest">Continue as guest</button>' + installCard() +
      '<p class="hint" style="text-align:center">Demo version: accounts are saved on this device only. Online accounts will come with Firebase.</p>' +
    "</div>";
  }

  // ---------- Home ----------
  function countOf(part) { return db.vocab.filter(function (v) { return v.part === part; }).length; }

  function homeScreen() {
    var u = currentUser();
    var r = db.vocab.find(function (v) { return v.part === "reading"; });
    var waves = [20, 38, 54, 30, 60, 44, 26, 50, 34, 22].map(function (h) { return '<i style="height:' + h + '%"></i>'; }).join("");
    return installCard() + '<p class="hello">Hi, <b>' + esc(u.name) + "</b> — what will you learn today?</p>" +

      '<section class="part-card reading" aria-label="Reading">' +
        '<div class="left"><h2>Reading</h2>' +
          '<span class="chip-solid">Vocabulary</span>' +
          '<span class="pill-outline">' + I.layers + countOf("reading") + " words</span>" +
          '<a class="start" href="#/part/reading">Start ' + I.arrow + "</a></div>" +
        '<div class="mini" aria-hidden="true"><span class="w">' + esc(r ? r.word : "Word") + '</span><span class="m bn">' + esc(r ? r.bn : "") + '</span><span class="ln"></span><span class="ln short"></span></div>' +
      "</section>" +

      '<section class="part-card listening light" aria-label="Listening">' +
        '<div class="left"><h2>Listening</h2>' +
          '<span class="chip-solid">Book 10–20</span>' +
          '<span class="pill-outline">' + I.layers + countOf("listening") + " words</span>" +
          '<a class="start" href="#/part/listening">Start ' + I.arrow + "</a></div>" +
        '<div class="mini" aria-hidden="true"><div class="wave">' + waves + '</div><div class="play"><span class="dot"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></span>Part 1</div><span class="ln"></span><span class="ln short"></span></div>' +
      "</section>" +

      '<section class="part-card writing" aria-label="Writing">' +
        '<div class="left"><h2>Writing</h2>' +
          '<span class="chip-solid">Task 1 &amp; Task 2</span>' +
          '<span class="pill-outline">' + I.trans + "With Bangla meanings</span>" +
          '<a class="start" href="#/part/writing">Start ' + I.arrow + "</a></div>" +
        '<div class="mini" aria-hidden="true"><div class="row-top">Task 2 <span style="color:#0F5848">' + I.pen + '</span></div><span class="ln yellow"></span><span class="ln yellow short"></span><span class="ln yellow"></span><span class="ln yellow short"></span></div>' +
      "</section>" +

      '<section class="part-card speaking light" aria-label="Speaking">' +
        '<div class="left"><h2>Speaking</h2>' +
          '<span class="chip-solid">Vocabulary by topic</span>' +
          '<span class="pill-outline">' + I.layers + db.cueCards.length + " cue cards</span>" +
          '<a class="start" href="#/part/speaking">Start ' + I.arrow + "</a></div>" +
        '<div class="mini" aria-hidden="true"><div class="bubble"><span class="ln"></span><span class="ln short"></span></div><span class="ln"></span><span class="ln short"></span></div>' +
      "</section>";
  }

  // ---------- Vocab part (Reading / Listening) ----------
  function vocabList(part) {
    var q = ui.query.trim().toLowerCase();
    return db.vocab.filter(function (v) {
      return v.part === part && (!q || v.word.toLowerCase().indexOf(q) !== -1 || (v.bn || "").indexOf(q) !== -1);
    });
  }
  function vocabItems(part) {
    var list = vocabList(part);
    if (!list.length) return '<p class="empty">No words found.</p>';
    return list.map(function (v) {
      return '<a class="item" href="#/word/' + esc(v.id) + '">' +
        '<span class="badge-letter">' + esc(v.word.charAt(0).toUpperCase()) + "</span>" +
        '<span class="txt"><b>' + esc(v.word) + '</b><span class="bn">' + esc(v.bn) + "</span></span>" +
        (isLearned(v.id) ? '<span class="done" aria-label="Learned">' + I.check + "</span>" : "") +
      "</a>";
    }).join("");
  }
  function vocabPart(part) {
    var P = PARTS[part];
    var extra = part === "reading" ? '<a class="link-light" href="#/passages">Reading passages →</a>' : '<a class="link-light" href="#/audios">Listening audio →</a>';
    return '<section class="banner ' + P.cls + '"><div class="row">' + backBtn("#/") + extra + "</div>" +
        "<h1>" + P.name + " Vocabulary</h1><p>" + countOf(part) + " words · synonyms, antonyms &amp; examples</p></section>" +
      '<label class="search"><span class="sr-only">Search words</span>' + I.search +
        '<input id="q" type="search" placeholder="Search in English or Bangla…" value="' + esc(ui.query) + '" autocomplete="off" data-part="' + part + '"></label>' +
      '<div class="list ' + P.cls + '-ctx" id="vlist">' + vocabItems(part) + "</div>";
  }

  function wordScreen(id) {
    var v = find("vocab", id);
    if (!v) return notFound();
    var P = PARTS[v.part] || PARTS.reading;
    var siblings = db.vocab.filter(function (x) { return x.part === v.part; });
    var idx = siblings.indexOf(v);
    var prev = siblings[idx - 1], next = siblings[idx + 1];
    var learned = isLearned(v.id);
    return '<section class="banner word-hero ' + P.cls + '">' +
        '<div class="row">' + backBtn("#/part/" + v.part) +
          '<button class="icon-btn" data-act="speak" data-v="' + esc(v.word) + '" aria-label="Play pronunciation">' + I.speaker + "</button></div>" +
        (v.pos ? '<span class="pos">' + esc(v.pos) + "</span>" : "") +
        "<h1>" + esc(v.word) + "</h1>" +
        '<span class="meaning bn">' + esc(v.bn) + "</span>" +
      "</section>" +
      '<div class="card"><h3>Synonyms</h3><div class="tags">' + (v.synonyms || []).map(function (s) { return '<span class="tag">' + esc(s) + "</span>"; }).join("") + "</div></div>" +
      '<div class="card"><h3>Antonyms</h3><div class="tags">' + (v.antonyms || []).map(function (s) { return '<span class="tag anti">' + esc(s) + "</span>"; }).join("") + "</div></div>" +
      '<div class="card"><h3>Examples</h3>' + (v.examples || []).map(function (e) { return '<p class="example" style="margin:0">' + highlight(e, [v.word]) + "</p>"; }).join("") + "</div>" +
      '<button class="btn block" data-act="learned" data-v="' + esc(v.id) + '">' + (learned ? I.check + " Learned — tap to undo" : "Mark as learned") + "</button>" +
      '<div class="btn-row">' +
        (prev ? '<a class="btn ghost" href="#/word/' + esc(prev.id) + '">← ' + esc(prev.word) + "</a>" : "<span></span>") +
        (next ? '<a class="btn ghost" href="#/word/' + esc(next.id) + '">' + esc(next.word) + " →</a>" : "<span></span>") +
      "</div>";
  }

  // ---------- Writing ----------
  function writingPart() {
    var f = ui.writingFilter;
    var list = db.writing.filter(function (w) { return f === "All" || w.task === f; });
    return '<section class="banner writing"><div class="row">' + backBtn("#/") + "</div><h1>Writing Topics</h1><p>Task 1 &amp; Task 2 with Bangla meanings</p></section>" +
      '<div class="seg" role="group" aria-label="Filter">' + ["All", "Task 1", "Task 2"].map(function (t) {
        return '<button data-act="wfilter" data-v="' + t + '" aria-pressed="' + (f === t) + '">' + t + "</button>";
      }).join("") + "</div>" +
      '<div class="list writing-ctx">' + (list.length ? list.map(function (w) {
        return '<a class="item" href="#/writing/' + esc(w.id) + '"><span class="badge-letter">' + esc(w.task.replace("Task ", "T")) + '</span><span class="txt"><b>' + esc(w.task) + '</b><span class="clamp">' + esc(w.topic) + "</span></span></a>";
      }).join("") : '<p class="empty">No topics yet.</p>') + "</div>";
  }
  function writingScreen(id) {
    var w = find("writing", id);
    if (!w) return notFound();
    return '<section class="banner writing"><div class="row">' + backBtn("#/part/writing") + "</div><h1>" + esc(w.task) + "</h1></section>" +
      '<div class="card"><h3>Topic</h3><p style="margin:0;font-size:17px;line-height:1.7">' + esc(w.topic) + "</p></div>" +
      vocabTable(w.vocab, "Useful vocabulary");
  }
  function vocabTable(list, title) {
    list = list || [];
    return '<div class="card"><h3>' + title + "</h3>" + (list.length ? list.map(function (p) {
      return '<div class="vrow"><b>' + esc(p.word) + '</b><span class="bn">' + esc(p.bn) + "</span></div>";
    }).join("") : '<p class="hint">No vocabulary added yet.</p>') + "</div>";
  }

  // ---------- Speaking ----------
  function speakingPart() {
    return '<section class="banner speaking"><div class="row">' + backBtn("#/") + "</div><h1>Speaking Cue Cards</h1><p>Vocabulary by topic</p></section>" +
      '<div class="list speaking-ctx">' + (db.cueCards.length ? db.cueCards.map(function (c, i) {
        return '<a class="item" href="#/cue/' + esc(c.id) + '"><span class="badge-letter">' + (i + 1) + '</span><span class="txt"><b>' + esc(c.topic) + "</b><span>" + (c.vocab || []).length + " words</span></span></a>";
      }).join("") : '<p class="empty">No cue cards yet.</p>') + "</div>";
  }
  function cueScreen(id) {
    var c = find("cueCards", id);
    if (!c) return notFound();
    return '<section class="banner speaking"><div class="row">' + backBtn("#/part/speaking") + "</div><h1>Cue Card</h1></section>" +
      '<div class="card"><h3>Topic</h3><p style="margin:0;font-size:19px;font-weight:600;line-height:1.5">' + esc(c.topic) + "</p>" +
        (c.points && c.points.length ? '<p class="hint" style="margin:0">You should say:</p><ul class="points">' + c.points.map(function (p) { return "<li>" + esc(p) + "</li>"; }).join("") + "</ul>" : "") +
      "</div>" + vocabTable(c.vocab, "Topic vocabulary");
  }

  // ---------- Reading passages ----------
  function passagesScreen() {
    return '<section class="banner reading"><div class="row">' + backBtn("#/") + "</div><h1>Reading Passages</h1><p>Vocabulary words are highlighted</p></section>" +
      '<div class="list reading-ctx">' + (db.passages.length ? db.passages.map(function (p) {
        return '<a class="item" href="#/passage/' + esc(p.id) + '"><span class="badge-letter">' + I.doc + '</span><span class="txt"><b>' + esc(p.title) + "</b><span>" + esc(p.level || "") + "</span></span></a>";
      }).join("") : '<p class="empty">No passages yet.</p>') + "</div>";
  }
  function passageScreen(id) {
    var p = find("passages", id);
    if (!p) return notFound();
    var words = db.vocab.filter(function (v) { return v.part === "reading"; }).map(function (v) { return v.word; });
    return '<section class="banner reading"><div class="row">' + backBtn("#/passages") + "</div><h1>" + esc(p.title) + "</h1><p>" + esc(p.level || "") + "</p></section>" +
      '<div class="card"><div class="passage">' + highlight(p.text, words) + "</div></div>";
  }

  // ---------- Listening audio ----------
  function audiosScreen() {
    return '<section class="banner listening"><div class="row">' + backBtn("#/") + "</div><h1>Listening Audio</h1><p>Book · Test · Part</p></section>" +
      '<div class="list listening-ctx">' + (db.audios.length ? db.audios.map(function (a) {
        return '<a class="item" href="#/audio/' + esc(a.id) + '"><span class="badge-letter">' + I.headphones + '</span><span class="txt"><b>' + esc(a.title) + "</b><span>" + esc([a.book, a.test, a.section].filter(Boolean).join(" · ")) + "</span></span></a>";
      }).join("") : '<p class="empty">No audio yet.</p>') + "</div>";
  }
  function audioScreen(id) {
    var a = find("audios", id);
    if (!a) return notFound();
    var player = a.url && /^https?:\/\//i.test(a.url)
      ? '<audio controls preload="none" src="' + esc(a.url) + '"></audio>'
      : '<p class="msg info" style="margin:0">Audio not uploaded yet. Admin can add an audio link (Cloudflare) from the Admin Panel.</p>';
    return '<section class="banner listening"><div class="row">' + backBtn("#/audios") + "</div><h1>" + esc(a.title) + "</h1><p>" + esc([a.book, a.test, a.section].filter(Boolean).join(" · ")) + "</p></section>" +
      '<div class="card">' + player + "</div>" +
      (a.transcript ? '<div class="card"><h3>Transcript</h3><div class="passage">' + esc(a.transcript) + "</div></div>" : "");
  }

  // ---------- Dashboard ----------
  function dashboardScreen() {
    var p = getProg();
    var r = db.vocab.filter(function (v) { return v.part === "reading"; });
    var l = db.vocab.filter(function (v) { return v.part === "listening"; });
    function learnedIn(list) { return list.filter(function (v) { return p.learned.indexOf(v.id) !== -1; }).length; }
    function bar(label, done, total, color) {
      var pct = total ? Math.round(done / total * 100) : 0;
      return '<div class="progress-row"><div class="top"><span>' + label + "</span><span>" + done + " / " + total + '</span></div><div class="bar"><i style="width:' + pct + "%;background:" + color + '"></i></div></div>';
    }
    var totalLearned = learnedIn(r) + learnedIn(l);
    return '<div class="page-head"><div><h1>Dashboard</h1><p>Your learning progress</p></div></div>' +
      '<div class="stats">' +
        '<div class="stat"><span>Words learned</span><b>' + totalLearned + " / " + (r.length + l.length) + "</b></div>" +
        '<div class="stat"><span>Today</span><b>' + p.day.count + " / " + p.goal + "</b></div>" +
      "</div>" +
      '<div class="card"><h3>By part</h3>' +
        bar("Reading vocabulary", learnedIn(r), r.length, "var(--reading)") +
        bar("Listening vocabulary", learnedIn(l), l.length, "var(--listening)") +
        bar("Today's goal", Math.min(p.day.count, p.goal), p.goal, "var(--accent)") +
      "</div>" +
      '<div class="stats">' +
        '<a class="stat" href="#/passages" style="text-decoration:none;color:inherit"><span>Reading passages</span><b>' + db.passages.length + "</b></a>" +
        '<a class="stat" href="#/audios" style="text-decoration:none;color:inherit"><span>Listening audio</span><b>' + db.audios.length + "</b></a>" +
        '<a class="stat" href="#/part/writing" style="text-decoration:none;color:inherit"><span>Writing topics</span><b>' + db.writing.length + "</b></a>" +
        '<a class="stat" href="#/part/speaking" style="text-decoration:none;color:inherit"><span>Cue cards</span><b>' + db.cueCards.length + "</b></a>" +
      "</div>";
  }

  // ---------- Plan ----------
  var PLAN_TASKS = [
    { k: "words", label: function (p) { return "Learn " + p.goal + " new words"; } },
    { k: "passage", label: function () { return "Read one reading passage"; } },
    { k: "audio", label: function () { return "Listen to one audio"; } },
    { k: "writing", label: function () { return "Plan one writing topic"; } },
    { k: "speaking", label: function () { return "Practise one cue card aloud"; } }
  ];
  function planScreen() {
    var p = getProg();
    var done = PLAN_TASKS.filter(function (t) { return p.day.tasks[t.k]; }).length;
    return '<div class="page-head"><div><h1>Plan</h1><p>' + today() + "</p></div></div>" +
      '<div class="card"><h3>Daily word goal</h3><div class="seg" role="group" aria-label="Daily goal">' +
        [5, 10, 20, 30].map(function (g) { return '<button data-act="goal" data-v="' + g + '" aria-pressed="' + (p.goal === g) + '">' + g + " words</button>"; }).join("") +
      '</div><div class="progress-row"><div class="top"><span>Learned today</span><span>' + Math.min(p.day.count, p.goal) + " / " + p.goal + '</span></div><div class="bar"><i style="width:' + Math.min(100, Math.round(p.day.count / p.goal * 100)) + '%"></i></div></div></div>' +
      '<div class="card"><h3>Today\'s tasks · ' + done + " / " + PLAN_TASKS.length + "</h3>" +
        PLAN_TASKS.map(function (t) {
          return '<label class="check"><input type="checkbox" data-task="' + t.k + '"' + (p.day.tasks[t.k] ? " checked" : "") + "> " + esc(t.label(p)) + "</label>";
        }).join("") +
      "</div>";
  }

  // ---------- Notifications ----------
  function notificationsScreen() {
    var list = db.notifications.slice().sort(function (a, b) { return (b.date || "").localeCompare(a.date || ""); });
    return '<div class="page-head"><div><h1>Notifications</h1><p>' + list.length + " messages</p></div></div>" +
      '<div class="list">' + (list.length ? list.map(function (n) {
        return '<div class="item"><span class="badge-letter">' + I.bell + '</span><span class="txt"><b>' + esc(n.title) + "</b><span>" + esc(n.body) + '</span><span style="font-size:12px">' + esc(n.date || "") + "</span></span></div>";
      }).join("") : '<p class="empty">No notifications.</p>') + "</div>";
  }

  // ---------- Profile ----------
  function profileScreen() {
    var u = currentUser();
    var guest = u.role === "guest";
    return '<div class="page-head"><div><h1>Profile</h1></div></div>' +
      '<div class="card" style="align-items:center;text-align:center">' +
        '<span class="avatar" style="width:84px;height:84px;font-size:32px">' + initial(u.name) + "</span>" +
        '<b style="font-size:20px">' + esc(u.name) + "</b>" +
        (u.email ? '<span class="hint">' + esc(u.email) + "</span>" : "") +
        '<span class="role-badge ' + u.role + '">' + (u.role === "admin" ? "Admin" : guest ? "Guest" : "Student") + "</span>" +
      "</div>" +
      (guest
        ? '<div class="msg info">You are using a guest account. Sign up to keep your progress under your own name.</div><button class="btn block" data-act="to-signup">Sign up</button>'
        : '<form class="form card" data-form="profile"><div class="field"><label for="p-name">Display name</label><input id="p-name" name="name" value="' + esc(u.name) + '" required></div><button class="btn block" type="submit">Save</button></form>') +
      '<button class="btn danger block" data-act="logout">' + I.logout + " Sign out</button>";
  }

  // ---------- Admin ----------
  var SCHEMAS = {
    vocab: { label: "Vocabulary", coll: "vocab", prefix: "v", fields: [
      { k: "part", label: "Part", type: "select", opts: ["reading", "listening"] },
      { k: "word", label: "Word", req: true },
      { k: "pos", label: "Part of speech (noun, verb…)" },
      { k: "bn", label: "Bangla meaning", req: true },
      { k: "synonyms", label: "3 Synonyms", type: "list", n: 3 },
      { k: "antonyms", label: "3 Antonyms", type: "list", n: 3 },
      { k: "examples", label: "2 Examples", type: "list", n: 2, wide: true }
    ], title: function (x) { return x.word; }, sub: function (x) { return x.part + " · " + x.bn; } },
    passages: { label: "Reading Passage", coll: "passages", prefix: "p", fields: [
      { k: "title", label: "Title", req: true },
      { k: "level", label: "Type", type: "select", opts: ["Academic", "General Training"] },
      { k: "text", label: "Passage text", type: "textarea", req: true }
    ], title: function (x) { return x.title; }, sub: function (x) { return x.level; } },
    audios: { label: "Listening Audio", coll: "audios", prefix: "a", fields: [
      { k: "title", label: "Title", req: true },
      { k: "book", label: "Book (e.g. Book 10)" },
      { k: "test", label: "Test (e.g. Test 1)" },
      { k: "section", label: "Part", type: "select", opts: ["Part 1", "Part 2", "Part 3", "Part 4"] },
      { k: "url", label: "Audio link (https://… from Cloudflare)" },
      { k: "transcript", label: "Transcript (optional)", type: "textarea" }
    ], title: function (x) { return x.title; }, sub: function (x) { return [x.book, x.test, x.section].filter(Boolean).join(" · ") + (x.url ? "" : " · no audio"); } },
    writing: { label: "Writing Topic", coll: "writing", prefix: "w", fields: [
      { k: "task", label: "Task", type: "select", opts: ["Task 1", "Task 2"] },
      { k: "topic", label: "Topic / question", type: "textarea", req: true },
      { k: "vocab", label: "Vocabulary (word + Bangla)", type: "pairs", n: 5 }
    ], title: function (x) { return x.task; }, sub: function (x) { return x.topic; } },
    cueCards: { label: "Speaking Cue Card", coll: "cueCards", prefix: "c", fields: [
      { k: "topic", label: "Cue card topic", req: true },
      { k: "points", label: "You should say (points)", type: "list", n: 4, wide: true },
      { k: "vocab", label: "Vocabulary (word + Bangla)", type: "pairs", n: 5 }
    ], title: function (x) { return x.topic; }, sub: function (x) { return (x.vocab || []).length + " words"; } },
    notifications: { label: "Notification", coll: "notifications", prefix: "n", fields: [
      { k: "title", label: "Title", req: true },
      { k: "body", label: "Message", type: "textarea", req: true }
    ], title: function (x) { return x.title; }, sub: function (x) { return x.date + " · " + x.body; } }
  };
  var ADMIN_TABS = [["vocab", "Vocabulary"], ["passages", "Reading Passage"], ["audios", "Listening Audio"], ["writing", "Writing Topic"], ["cueCards", "Cue Card"], ["notifications", "Notifications"], ["students", "Students"], ["backup", "Import / Backup"]];

  function fieldHTML(f, item) {
    var v = item ? item[f.k] : undefined;
    var id = "af-" + f.k;
    if (f.type === "select") {
      return '<div class="field"><label for="' + id + '">' + f.label + '</label><select id="' + id + '" name="' + f.k + '">' +
        f.opts.map(function (o) { return '<option value="' + esc(o) + '"' + (v === o ? " selected" : "") + ">" + esc(o) + "</option>"; }).join("") + "</select></div>";
    }
    if (f.type === "textarea") {
      return '<div class="field"><label for="' + id + '">' + f.label + '</label><textarea id="' + id + '" name="' + f.k + '"' + (f.req ? " required" : "") + ">" + esc(v || "") + "</textarea></div>";
    }
    if (f.type === "list") {
      var arr = v || [];
      var inputs = "";
      for (var i = 0; i < f.n; i++) {
        inputs += '<input name="' + f.k + "_" + i + '" aria-label="' + f.label + " " + (i + 1) + '" placeholder="' + (i + 1) + '" value="' + esc(arr[i] || "") + '">';
      }
      return '<div class="field"><span class="lbl">' + f.label + '</span><div class="' + (f.wide ? "form" : "grid-3") + '" style="gap:8px">' + inputs + "</div></div>";
    }
    if (f.type === "pairs") {
      var pairs = v || [];
      var rows = "";
      for (var j = 0; j < f.n; j++) {
        var pr = pairs[j] || {};
        rows += '<div class="grid-2"><input name="' + f.k + "_w_" + j + '" aria-label="Word ' + (j + 1) + '" placeholder="Word" value="' + esc(pr.word || "") + '">' +
          '<input name="' + f.k + "_b_" + j + '" aria-label="Bangla ' + (j + 1) + '" placeholder="বাংলা অর্থ" class="bn" value="' + esc(pr.bn || "") + '"></div>';
      }
      return '<div class="field"><span class="lbl">' + f.label + '</span><div class="form" style="gap:8px">' + rows + "</div></div>";
    }
    return '<div class="field"><label for="' + id + '">' + f.label + '</label><input id="' + id + '" name="' + f.k + '" value="' + esc(v || "") + '"' + (f.req ? " required" : "") + "></div>";
  }

  function adminScreen() {
    var tab = ui.adminTab;
    var head = '<div class="page-head"><div><h1>Admin Panel</h1><p>Upload and manage all content</p></div></div>' +
      '<div class="tabs-scroll" role="group" aria-label="Sections">' + ADMIN_TABS.map(function (t) {
        return '<button data-act="admin-tab" data-v="' + t[0] + '" aria-pressed="' + (tab === t[0]) + '">' + t[1] + "</button>";
      }).join("") + "</div>" +
      (ui.adminMsg ? '<div class="msg ' + ui.adminMsg.type + '">' + esc(ui.adminMsg.text) + "</div>" : "");

    if (tab === "students") return head + studentsAdmin();
    if (tab === "backup") return head + backupAdmin();

    var S = SCHEMAS[tab];
    var editing = ui.editId ? find(S.coll, ui.editId) : null;
    var form = '<form class="form card" data-form="admin-save">' +
      "<h3>" + (editing ? "Edit " : "Add ") + S.label + "</h3>" +
      S.fields.map(function (f) { return fieldHTML(f, editing); }).join("") +
      '<div class="btn-row"><button class="btn" type="submit">' + (editing ? "Save changes" : "Add") + "</button>" +
      (editing ? '<button class="btn ghost" type="button" data-act="admin-cancel">Cancel</button>' : '<button class="btn ghost" type="reset">Clear</button>') + "</div></form>";
    var items = db[S.coll].slice().reverse();
    var list = '<div class="card"><h3>' + S.label + " list · " + items.length + "</h3>" +
      (items.length ? items.map(function (x) {
        return '<div class="admin-item"><div class="txt"><b>' + esc(S.title(x)) + "</b><span>" + esc(S.sub(x)) + "</span></div>" +
          '<div class="acts"><button class="btn ghost small" data-act="admin-edit" data-v="' + esc(x.id) + '">Edit</button>' +
          '<button class="btn danger small" data-act="admin-del" data-v="' + esc(x.id) + '" aria-label="Delete ' + esc(S.title(x)) + '">Delete</button></div></div>';
      }).join("") : '<p class="hint">Nothing yet.</p>') + "</div>";
    return head + form + list;
  }

  function studentsAdmin() {
    var me = currentUser();
    return '<div class="card"><h3>Accounts · ' + db.users.length + "</h3>" + db.users.map(function (u) {
      var self = u.id === me.id;
      return '<div class="admin-item"><span class="avatar" style="width:40px;height:40px;font-size:15px;border-width:2px">' + initial(u.name) + "</span>" +
        '<div class="txt"><b>' + esc(u.name) + (self ? " (you)" : "") + "</b><span>" + esc(u.email) + " · " + esc(u.role) + "</span></div>" +
        (self ? "" : '<div class="acts"><button class="btn ghost small" data-act="role" data-v="' + esc(u.id) + '">' + (u.role === "admin" ? "Make student" : "Make admin") + "</button>" +
          '<button class="btn danger small" data-act="user-del" data-v="' + esc(u.id) + '" aria-label="Delete ' + esc(u.name) + '">Delete</button></div>') +
      "</div>";
    }).join("") + '<p class="hint">Students sign up from the sign-in screen. Demo accounts live on this device only.</p></div>';
  }

  function backupAdmin() {
    return '<form class="form card" data-form="import-vocab"><h3>Bulk import vocabulary</h3>' +
      '<p class="hint" style="margin:0">One word per line, separated by <b>|</b> :<br>part | word | pos | Bangla | syn1 | syn2 | syn3 | ant1 | ant2 | ant3 | example1 | example2</p>' +
      '<div class="field"><label for="imp">Paste lines</label><textarea id="imp" name="lines" placeholder="reading | Vivid | adjective | প্রাণবন্ত | bright | intense | lively | dull | faint | pale | She has a vivid imagination. | The photos are vivid."></textarea></div>' +
      '<button class="btn block" type="submit">Import words</button></form>' +
      '<div class="card"><h3>Backup</h3><p class="hint" style="margin:0">Download all content as a file, or restore it later.</p>' +
        '<button class="btn ghost block" data-act="backup">Download backup (.json)</button>' +
        '<label class="btn ghost block" style="cursor:pointer">Restore from backup<input type="file" accept="application/json,.json" data-act="restore" class="sr-only"></label>' +
        '<button class="btn danger block" data-act="reset">Reset to demo content</button></div>';
  }

  function notFound() { return '<p class="empty">This page was not found.</p><a class="btn ghost" href="#/">Go home</a>'; }
  function adminOnly() { return '<div class="msg err">Admin access only.</div><a class="btn ghost" href="#/">Go home</a>'; }

  /* ================= Chrome: sidebar & tab bar ================= */
  function renderSidebar(path) {
    var u = currentUser();
    if (!u) { sidebar.innerHTML = ""; return; }
    function link(href, icon, label, swatch) {
      var cur = path === href.slice(1) ? ' aria-current="page"' : "";
      return '<a class="side-link" href="' + href + '"' + cur + ">" + (swatch ? '<span class="sw" style="background:' + swatch + '"></span>' : icon) + label + "</a>";
    }
    sidebar.innerHTML =
      '<a class="side-profile" href="#/profile"><span class="avatar">' + initial(u.name) + "</span><div><b>" + esc(u.name) + '</b><span class="role-badge ' + u.role + '">' + (u.role === "admin" ? "Admin" : u.role === "guest" ? "Guest" : "Student") + "</span></div></a>" +
      link("#/", I.home, "Home") +
      link("#/dashboard", I.chart, "Dashboard") +
      '<div class="side-label">Practice</div>' +
      link("#/passages", "", "Reading Passage", "var(--reading)") +
      link("#/audios", "", "Listening Audio", "var(--listening)") +
      link("#/part/writing", "", "Writing Topic", "var(--writing)") +
      link("#/part/speaking", "", "Speaking Cue Card", "var(--speaking)") +
      '<div class="side-label">Account</div>' +
      link("#/plan", I.plan, "Plan") +
      link("#/notifications", I.bell, "Notifications") +
      link("#/profile", I.user, "Profile") +
      (u.role === "admin" ? link("#/admin", I.shield, "Admin Panel") : "") +
      (installEvt ? '<button class="side-link" data-act="install">' + I.plus + "Install app</button>" : "") +
      (u.role === "guest"
        ? '<button class="side-link" data-act="to-signup">' + I.login + "Sign up / Sign in</button>"
        : '<button class="side-link" data-act="logout">' + I.logout + "Sign out</button>");
  }

  function renderTabbar(path) {
    var admin = isAdmin();
    var tabs = [
      ["#/", I.home, "Home", ""],
      ["#/plan", I.plan, "Plan", ""],
      admin ? ["#/admin", I.plus, "Admin", "center"] : ["#/part/reading", I.book, "Learn", "center"],
      ["#/dashboard", I.chart, "Dashboard", ""],
      ["#/notifications", I.bell, "Notifications", ""]
    ];
    tabbar.innerHTML = tabs.map(function (t) {
      var cur = path === t[0].slice(1) ? ' aria-current="page"' : "";
      return '<a href="' + t[0] + '" class="' + t[3] + '"' + cur + '><span class="ic">' + t[1] + "</span>" + t[2] + "</a>";
    }).join("");
  }

  function openSidebar(open) {
    sidebar.classList.toggle("open", open);
    sidebar.setAttribute("aria-hidden", String(!open));
    menuBtn.setAttribute("aria-expanded", String(open));
    scrim.hidden = !open;
    if (open) { var f = sidebar.querySelector("a,button"); if (f) f.focus(); }
  }

  /* ================= Router ================= */
  function route() {
    var path = (location.hash.replace(/^#/, "") || "/");
    var parts = path.split("/").filter(Boolean);
    var u = currentUser();
    openSidebar(false);

    if (!u) {
      document.body.classList.add("auth");
      app.innerHTML = authScreen();
      return;
    }
    document.body.classList.remove("auth");
    document.getElementById("topAvatar").textContent = (u.name || "?").charAt(0).toUpperCase();

    var html;
    var a = parts[0], b = parts[1];
    if (!a) html = homeScreen();
    else if (a === "part" && (b === "reading" || b === "listening")) html = vocabPart(b);
    else if (a === "part" && b === "writing") html = writingPart();
    else if (a === "part" && b === "speaking") html = speakingPart();
    else if (a === "word") html = wordScreen(b);
    else if (a === "writing") html = writingScreen(b);
    else if (a === "cue") html = cueScreen(b);
    else if (a === "passages") html = passagesScreen();
    else if (a === "passage") html = passageScreen(b);
    else if (a === "audios") html = audiosScreen();
    else if (a === "audio") html = audioScreen(b);
    else if (a === "dashboard") html = dashboardScreen();
    else if (a === "plan") html = planScreen();
    else if (a === "notifications") html = notificationsScreen();
    else if (a === "profile") html = profileScreen();
    else if (a === "admin") html = isAdmin() ? adminScreen() : adminOnly();
    else html = notFound();

    app.innerHTML = html;
    renderSidebar(path);
    renderTabbar(path);
    window.scrollTo(0, 0);
  }

  function rerender() { var y = window.scrollY; route(); window.scrollTo(0, y); }

  /* ================= Events ================= */
  menuBtn.addEventListener("click", function () { openSidebar(!sidebar.classList.contains("open")); });
  scrim.addEventListener("click", function () { openSidebar(false); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && sidebar.classList.contains("open")) { openSidebar(false); menuBtn.focus(); } });

  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-act]");
    if (!el || el.tagName === "INPUT") return;
    var act = el.getAttribute("data-act"), v = el.getAttribute("data-v");
    var S;

    switch (act) {
      case "auth-tab": ui.authTab = v; ui.authMsg = ""; route(); break;
      case "guest": setSession({ guest: true }); ui.authMsg = ""; go("#/"); break;
      case "to-signup": setSession(null); ui.authTab = "signup"; ui.authMsg = ""; go("#/"); break;
      case "logout": setSession(null); ui.authTab = "signin"; ui.authMsg = { type: "ok", text: "You have signed out." }; go("#/"); break;
      case "speak": speak(v); break;
      case "install":
        if (installEvt) { installEvt.prompt(); installEvt.userChoice.then(function () { installEvt = null; rerenderSoft(); }); }
        break;
      case "learned": toggleLearned(v); rerender(); break;
      case "wfilter": ui.writingFilter = v; rerender(); break;
      case "goal": var p = getProg(); p.goal = Number(v); saveProg(p); rerender(); break;
      case "admin-tab": ui.adminTab = v; ui.editId = null; ui.adminMsg = ""; route(); break;
      case "admin-edit": ui.editId = v; ui.adminMsg = ""; route(); break;
      case "admin-cancel": ui.editId = null; ui.adminMsg = ""; route(); break;
      case "admin-del":
        S = SCHEMAS[ui.adminTab];
        var item = find(S.coll, v);
        if (item && confirm('Delete "' + S.title(item) + '"?')) {
          db[S.coll] = db[S.coll].filter(function (x) { return x.id !== v; });
          saveDb(); if (ui.editId === v) ui.editId = null;
          ui.adminMsg = { type: "ok", text: "Deleted." }; rerender();
        }
        break;
      case "role":
        var usr = find("users", v);
        if (usr) { usr.role = usr.role === "admin" ? "student" : "admin"; saveDb(); ui.adminMsg = { type: "ok", text: usr.name + " is now " + usr.role + "." }; rerender(); }
        break;
      case "user-del":
        var ud = find("users", v);
        if (ud && confirm("Delete account " + ud.email + "?")) {
          db.users = db.users.filter(function (x) { return x.id !== v; }); saveDb();
          lsDel("vm_prog_" + v);
          ui.adminMsg = { type: "ok", text: "Account deleted." }; rerender();
        }
        break;
      case "backup":
        var blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob); link.download = "vocabmaster-backup-" + today() + ".json";
        document.body.appendChild(link); link.click(); link.remove();
        setTimeout(function () { URL.revokeObjectURL(link.href); }, 2000);
        break;
      case "reset":
        if (confirm("Replace all content with the demo content? Accounts are kept.")) {
          var users = db.users; db = clone(window.SEED); db.users = users; saveDb();
          ui.adminMsg = { type: "ok", text: "Demo content restored." }; rerender();
        }
        break;
    }
  });

  document.addEventListener("input", function (e) {
    if (e.target.id === "q") {
      ui.query = e.target.value;
      var list = document.getElementById("vlist");
      if (list) list.innerHTML = vocabItems(e.target.getAttribute("data-part"));
    }
  });

  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.hasAttribute("data-task")) {
      var p = getProg(); p.day.tasks[t.getAttribute("data-task")] = t.checked; saveProg(p); rerender();
    }
    if (t.getAttribute("data-act") === "restore" && t.files && t.files[0]) {
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var data = JSON.parse(reader.result);
          if (!data || !Array.isArray(data.vocab)) throw new Error("bad");
          var me = currentUser();
          db = data;
          if (!Array.isArray(db.users)) db.users = [];
          if (me && me.role === "admin" && !find("users", me.id)) db.users.push(me);
          saveDb(); ui.adminMsg = { type: "ok", text: "Backup restored." };
        } catch (err) { ui.adminMsg = { type: "err", text: "That file is not a VocabMaster backup." }; }
        rerender();
      };
      reader.readAsText(t.files[0]);
    }
  });

  document.addEventListener("submit", function (e) {
    var form = e.target.closest("form[data-form]");
    if (!form) return;
    e.preventDefault();
    var kind = form.getAttribute("data-form");
    var fd = new FormData(form);
    function val(k) { return String(fd.get(k) || "").trim(); }

    if (kind === "signin") {
      var email = val("email").toLowerCase();
      sha256(val("pass")).then(function (h) {
        var u = db.users.find(function (x) { return x.email.toLowerCase() === email; });
        if (!u || u.passHash !== h) { ui.authMsg = { type: "err", text: "Email or password is wrong." }; route(); return; }
        setSession({ uid: u.id }); ui.authMsg = ""; go("#/");
      });
    }
    else if (kind === "signup") {
      var em = val("email").toLowerCase();
      if (db.users.some(function (x) { return x.email.toLowerCase() === em; })) {
        ui.authMsg = { type: "err", text: "An account with this email already exists. Please sign in." }; route(); return;
      }
      if (val("pass").length < 6) { ui.authMsg = { type: "err", text: "Password must be at least 6 characters." }; route(); return; }
      sha256(val("pass")).then(function (h) {
        var nu = { id: uid("u_"), name: val("name"), email: em, passHash: h, role: "student", joined: today() };
        db.users.push(nu); saveDb();
        setSession({ uid: nu.id }); ui.authMsg = ""; go("#/");
      });
    }
    else if (kind === "profile") {
      var me = currentUser();
      if (me && me.role !== "guest") { me.name = val("name") || me.name; saveDb(); rerender(); }
    }
    else if (kind === "admin-save") {
      if (!isAdmin()) return;
      var S = SCHEMAS[ui.adminTab];
      var obj = ui.editId ? find(S.coll, ui.editId) : { id: uid(S.prefix) };
      S.fields.forEach(function (f) {
        if (f.type === "list") {
          var arr = [];
          for (var i = 0; i < f.n; i++) { var x = val(f.k + "_" + i); if (x) arr.push(x); }
          obj[f.k] = arr;
        } else if (f.type === "pairs") {
          var pairs = [];
          for (var j = 0; j < f.n; j++) {
            var w = val(f.k + "_w_" + j), b = val(f.k + "_b_" + j);
            if (w) pairs.push({ word: w, bn: b });
          }
          obj[f.k] = pairs;
        } else {
          obj[f.k] = val(f.k);
        }
      });
      if (S.coll === "notifications" && !obj.date) obj.date = today();
      if (S.coll === "audios" && obj.url && !/^https?:\/\//i.test(obj.url)) {
        ui.adminMsg = { type: "err", text: "Audio link must start with https://" }; rerender(); return;
      }
      if (!ui.editId) db[S.coll].push(obj);
      saveDb();
      ui.adminMsg = { type: "ok", text: (ui.editId ? "Saved: " : "Added: ") + S.title(obj) };
      ui.editId = null;
      route();
    }
    else if (kind === "import-vocab") {
      if (!isAdmin()) return;
      var lines = val("lines").split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
      var added = 0, skipped = 0;
      lines.forEach(function (l) {
        var c = l.split("|").map(function (s) { return s.trim(); });
        var part = (c[0] || "").toLowerCase();
        if ((part !== "reading" && part !== "listening") || !c[1] || !c[3]) { skipped++; return; }
        db.vocab.push({
          id: uid("v"), part: part, word: c[1], pos: c[2] || "", bn: c[3],
          synonyms: c.slice(4, 7).filter(Boolean), antonyms: c.slice(7, 10).filter(Boolean), examples: c.slice(10, 12).filter(Boolean)
        });
        added++;
      });
      saveDb();
      ui.adminMsg = { type: added ? "ok" : "err", text: added + " words imported" + (skipped ? ", " + skipped + " lines skipped (check part, word and Bangla)." : ".") };
      rerender();
    }
  });

  window.addEventListener("hashchange", route);
  route();

  if (!IN_APK && "serviceWorker" in navigator) {
    window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
  }
})();
