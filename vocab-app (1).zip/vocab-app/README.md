# IELTS VocabMaster (ডেমো)

Reading, Listening, Writing, Speaking — চার পার্টের IELTS ভোকাবুলারি অ্যাপ।

## কী কী আছে
- **Reading ও Listening:** প্রতিটা শব্দের বাংলা অর্থ, ৩টা synonym, ৩টা antonym, ২টা example
- **Writing:** Task 1 ও Task 2 টপিক, বাংলা অর্থসহ ভোকাবুলারি
- **Speaking:** Cue card, বিষয়ভিত্তিক ভোকাবুলারি
- **সাইডবার:** Profile, Dashboard, Reading Passage, Listening Audio, Writing Topic, Speaking Cue Card, Plan, Notifications
- **অ্যাকাউন্ট:** Sign up / Sign in (স্টুডেন্ট), Guest হিসেবে ঢোকা
- **Admin Panel:** সব কিছু যোগ, এডিট, ডিলিট; একসাথে অনেক শব্দ ইমপোর্ট; ব্যাকআপ

## ডেমো অ্যাডমিন
- ইমেইল: `admin@vocabmaster.app`
- পাসওয়ার্ড: `admin123`

## জরুরি কথা (ডেমো)
এই ভার্সনে অ্যাকাউন্ট আর অ্যাডমিন যা আপলোড করবেন, সব **ওই ফোনের ব্রাউজারেই** থাকে।
অন্য ফোনে বা অন্য স্টুডেন্টের কাছে তা যাবে না। Firebase যুক্ত হলে সবার কাছে একই ডাটা যাবে,
আর তখন অ্যাডমিন পাসওয়ার্ডও নিরাপদ হবে।

## আপডেট করার নিয়ম
নতুন `vocab-app.zip` GitHub-এ আপলোড করুন (পুরনোটার ওপর)। Actions নিজে থেকেই অ্যাপ আপডেট করবে।
